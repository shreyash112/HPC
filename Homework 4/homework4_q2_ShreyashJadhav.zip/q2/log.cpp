//Program for q2
#include<mpi.h>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<vector>
#include<algorithm>
using namespace std;

double CLOCK() {
	struct timespec t;
	clock_gettime(CLOCK_MONOTONIC,  &t);
	return (t.tv_sec * 1000)+(t.tv_nsec*1e-6);
}

//Function to generate the randim numbers
int 
random_1(){
	int i = rand() % 1000;
	return i;
}

//function to generate the vector of random numbers
vector<int> 
gen_random(int q){
	srand(time(NULL));
	vector<int> numbers(q);
	for(int ii =0; ii < numbers.size(); ++ii){
		numbers[ii] = random_1();
	}
	return numbers;	
}

class histogram 
{	
	private:
	vector<int> bins;
	vector<int> results;
	vector<int> gen_num;//number generated
	int num_classes,index_f,index_l;
	int max_number;//1000
	int rank; //number of bins in the histogram
	int intervals; //size of each bin/class
	MPI_Comm comm;
	int total_procs;
	int proc_id;
	int proc_size; //numbers given to each node
	public:
	histogram(MPI_Comm comm, vector<int> vec, int num_classes);
	void run();
	int bin_Val(int val);
	void print_results();
	
};
//Constructor to init
	histogram::histogram(MPI_Comm commu,vector<int> vec, int num_classes):bins(num_classes),results(num_classes)
	{	
		//cout << "Start"<<endl;
		this -> comm = commu;
		this -> max_number = 1000;
		this -> gen_num = vec;
		this -> num_classes = num_classes;	
		//cout << "Before size"<<endl;
		MPI_Comm_size(this -> comm, &this -> total_procs);
		MPI_Comm_rank(this -> comm, &this -> proc_id);	
		this -> intervals = this -> max_number / num_classes;
		this -> proc_size =  vec.size() / this -> total_procs;
		//cout << this -> proc_size << endl;
		//Indexing for the each nodes
		this -> index_f = this -> proc_id * proc_size; //start-index
		this -> index_l = (this -> proc_id + 1) * proc_size; //end-index
		//this -> index_l = std::min(this -> index_l, (int)vec.size());

	}
	
	void histogram::run()
	{
		
	//	cout <<"process running: "<< this -> proc_id <<endl;
		for(int i = this -> index_f; i < this -> index_l; ++i)
		{
			bins[bin_Val(gen_num[i])]++;
		}
		//Collect data from all the nodes to a master node(0)
		MPI_Reduce(this -> bins.data(), this -> results.data(), this -> bins.size(), MPI_INT, MPI_SUM, 0, this -> comm);
	}

	void histogram::print_results() 
	{
		if(this -> proc_id == 0){
		cout <<" Classes: " << endl;
       		int min, max, sum=0;
        		for(int ii = 0; ii < this->results.size(); ++ii) 
			{
            			min = ii * this -> max_number / this -> num_classes;
            			max = (ii + 1) * this -> max_number / this -> num_classes;
            			sum += results[ii];
            			cout << "(" << min << ", " << max << "): " << results[ii] << endl;
        		}	
        cout << "Sum: " << sum << endl;	
	}
	}	

	//hashing in the bins
	int histogram::bin_Val(int val)
	{	
		int num = this -> num_classes;
		int intervals = this -> max_number / this -> num_classes;
		int range_min, range_max;
		for(int j = 0; j < num; j++)
		{
			range_min =  j *  intervals;
			range_max = (j + 1) *  intervals;
			if(range_min <= val && val < range_max)
				return j;
		}

	} 

class 
histogram_2
{
	private:
	vector<int> numbers;
	vector<int> results;
	int size,size_class;
	int min, max,count; 
	int rank,max_number;
	MPI_Comm comm;
	int classes;
	public:
	//void run();
	histogram_2(MPI_Comm comm, vector<int> vec);
	void run();
	void print_results();
	bool bin_Val(int val);
};

	histogram_2::histogram_2(MPI_Comm comm, vector<int> number)
	{
		this -> comm = comm;
		this -> numbers = number;
		this -> max_number = 1000;//for the range
		MPI_Comm_rank(this -> comm, &this -> rank);
		MPI_Comm_size(this -> comm, &this -> size);
		this -> classes = this -> size;
//		this -> rank = this -> rank * 2;
		//this -> size = this -> size;
		this -> size_class = 1000/ this -> classes; //size of each class
		this -> results = vector<int>(this -> size);
		this -> min = this -> rank * this -> size_class;
		this -> max = (this -> rank + 1) * this -> size_class;
		//if(rank == 0 )
		//	cout << "In the problem 2"<<endl;
	}
	void histogram_2::run()
	{
		for(int ii = 0; ii < this -> numbers.size();++ii)
		{
			if(bin_Val(this -> numbers[ii]))
			{
				count++;
			}	
		}
	MPI_Gather(&this->count, 1, MPI_INT, this->results.data(), 1, MPI_INT, 0, this->comm);
					
			
	}
	bool histogram_2:: bin_Val(int num)
	{
		bool a;
		a = (this -> min <= num) && (num < this -> max);
		return a;
	}

	 	
	void histogram_2::print_results() 
	{
		int min, max, sum = 0;
	    if(this->rank == 0) 
	    {
	//	cout << results.size() << endl;
            	for(int idx = 0; idx < this->results.size(); ++idx)
		 {
            		min = idx * this->max_number / this-> size;
            		max = (idx + 1) * this->max_number / this->size;
            		sum += this->results[idx];
            		cout << "(" << min << ", " << max << "): " << this->results[idx] << endl;
       		 }	
       		 cout << "Sum: " << sum << endl;
            }
		
      	}	

void print_vec(vector<int> new1)
{
	for(auto i = new1.begin(); i != new1.end(); i++){
		cout << *i << " " ;
	}
	cout << endl;
}

int 
main(int argc, char* argv[]){
	int num = atoi(argv[1]);//number of integers
	int classes = atoi(argv[2]);//number of classes
	int problem_2 = atoi(argv[3]);//a -> 1 and b -> 0
	/*
	if(argc != 3)
	{
		cout << "log <N> <number of classes> <method a = 1 or b = 0>"<<endl;
	}*/
	double start,finish,total;

	MPI_Init(&argc, &argv);	
	int rank,size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);	
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	vector<int> new1(num);	
	new1 = gen_random(num);
	MPI_Bcast(&num, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&classes, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&new1.front(), new1.size(), MPI_INT, 0, MPI_COMM_WORLD);

	if(problem_2)
	{
		histogram hist(MPI_COMM_WORLD, new1, classes);	
		if(rank == 0)
		{
			cout << "Total processes running are: "<< size <<endl;
			start = CLOCK();	
		}

		MPI_Barrier(MPI_COMM_WORLD);
		hist.run();
		MPI_Barrier(MPI_COMM_WORLD);

		if(rank == 0 )
		{
			cout << "Processes completed" <<endl;
			finish = CLOCK();
			total = finish - start;
			cout << "Time taken :" << total<< " ms"  <<endl;	
		}
		//MPI_Barrier(MPI_COMM_WORLD);
		hist.print_results();
		MPI_Finalize();
	}
	else
	{
		histogram_2 hist(MPI_COMM_WORLD, new1);
		if(rank == 0)
		{
			cout << "Total processes running are: "<< size <<endl;
			start = CLOCK();	
		}

		MPI_Barrier(MPI_COMM_WORLD);
		hist.run();
		MPI_Barrier(MPI_COMM_WORLD);

		if(rank == 0 )
		{
			cout << "Processes completed" <<endl;
			finish = CLOCK();
			total = finish - start;
			cout << "Time taken :" << total<< " ms"  <<endl;	
		}
		//MPI_Barrier(MPI_COMM_WORLD);
		hist.print_results();
		MPI_Finalize();
	}
	//hist.print_results();
	//MPI_Finalize();
	return 0;
}
