#include<mpi.h>

class dartBoard {

	private:
		MPI_Comm comm;
		int rank, procs;//rank and number of proceses
		int throws_procs, success_circle, total_success; 
		void master();//call if rank == 0 
		void slave(); // call if rank > 0
		void throw_dart(); //genrate x and y values and check if it is inside the circle
		bool success_check(double x, double y);//check if the dart is inside the circle
		double gen_random();//genrate x and y value between 0 and 1
		void computePI();// compute the value of pi depending on success of darts in the circle
	public:
		dartBoard(MPI_Comm comm, int throws);
		void run();
};
