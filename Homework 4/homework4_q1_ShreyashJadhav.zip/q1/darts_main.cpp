#include<mpi.h>
#include<iostream>
#include<stdio.h>
#include "darts.h"
//using namespace std;
using std::cout;
using std::endl;
// CLass dartBoard

double CLOCK() {
	struct timespec t;
	clock_gettime(CLOCK_MONOTONIC,  &t);
	return (t.tv_sec * 1000)+(t.tv_nsec*1e-6);
}
//constructor
dartBoard::dartBoard(MPI_Comm comm,int throws){
	MPI_Comm_rank(comm, &this -> rank);
	MPI_Comm_size(comm, &this -> procs);
	this -> comm = comm;
	this -> throws_procs = throws / this -> procs;
	this -> success_circle = 0;
	srand(time(NULL) + this -> rank);
}

void dartBoard::run(){
	if(this -> rank == 0)
		this -> master();
	else
		this -> slave();
	MPI_Reduce(&this->success_circle, &this->total_success,1,MPI_INT,MPI_SUM,0,MPI_COMM_WORLD);
	if(this -> rank == 0)
		this -> computePI();
}

void dartBoard::master(){
	cout << this -> procs << " processes running"<<endl;
	this -> slave();
}

void dartBoard::slave(){
	for(int i = 0; i < throws_procs; ++i){
		this -> throw_dart();
	}
	cout << "Process " << this->rank << " has " << this -> success_circle << " success"<<endl;
	
}
void dartBoard:: throw_dart(){
	double x = this->gen_random();
	double y = this -> gen_random();
	double area = (x*x) + (y*y);
	if(area <= 1){
		this -> success_circle++;
	}
}

double dartBoard::gen_random(){
	return rand() / (RAND_MAX + 1.);
}

void dartBoard::computePI(){
	double total_throws = this -> throws_procs * this -> procs;
	double pi = 4.0 * double(this -> total_success)/total_throws;
	cout << "Value of pi " << pi << endl;
}	 

int main(int argc, char *argv[])
{
	int num = atoi(argv[1]);
	
	MPI_Init(&argc, &argv);
	double start, finish, total;
	dartBoard dart(MPI_COMM_WORLD, num);
	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	if(rank == 0){ 
		start = CLOCK();
	}
	dart.run();
	
	if(rank == 0){
		finish = CLOCK();
	total = finish - start;
	cout << "Total time consumed " << total << "ms" << endl;
	}
	MPI_Finalize();
}
	
